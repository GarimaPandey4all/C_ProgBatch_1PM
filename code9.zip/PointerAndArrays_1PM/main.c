#include <stdio.h>
#include <stdlib.h>

int main()
{
    int values[10], i;

    int *pvalues = values;

    printf("Enter values in an Array[10]:");
    for(i=0; i<10; i++)
    {
        scanf("%d", pvalues+i);

    }

    for(i=0; i<10; i++)
    {
         printf("Entered values are:%d\n", *pvalues);
         pvalues++;
    }


    return 0;
}
