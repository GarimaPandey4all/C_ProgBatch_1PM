#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *fp;
    int c;

    fp = fopen("E:\\Training\\CPrograms\\FileHandlingExample\\bin\\Debug\\file.txt","r");
    //fp = fopen("file.txt","r");

    if(fp == NULL)
    {
                perror("Error in Opening file");
                //return (-1);
                exit(0);
    }

    while((c = fgetc(fp)) != EOF)
                printf("%c", c);

            fclose(fp);
            fp = NULL;

            //system("pause");
            return (0);
}
