#include <stdio.h>
#include <stdlib.h>

int main()
{
    //int arr[4]= {2,3,5,6}; //1-D Array //Declaration //traditional way for initialization

    //int arr[4]= {[1]=4,[3]=8}; // designated way

//    int arr[4] = 4;
//    arr[2] = 9;

    int arr[][5] = {{1,2,3,4,5}, //jagged Array
                    {3,4,5,6,7}};

    return 0;
}
