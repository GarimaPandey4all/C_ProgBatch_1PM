#include <stdio.h>
#include <stdlib.h>

int main()
{
    char Operator;
    int opd1, opd2;

    printf("Enter any Operator:");
    scanf("%c", &Operator);

    printf("Enter value for Operand 1:");
    scanf("%d", &opd1);

    printf("Enter value for Operand 2:");
    scanf("%d", &opd2);

    switch(Operator)
    {
    case '+':
        printf("\nAddition of Two Numbers is: %d", opd1 + opd2);
        break;

    case '-':
        printf("\nSubtraction of Two Numbers is: %d", opd1 - opd2);
        break;

    case '*':
        printf("\Multiply of Two Numbers is: %d", opd1 * opd2);
        break;

    case '/':
        printf("\Division of Two Numbers is: %d", opd1 / opd2);
        break;

    case '%':
        printf("\Modulus of Two Numbers is: %d", opd1 % opd2);
        break;

    default:
        printf("\nYou Entered wrong Operator");
    }

    //printf("Hello world!\n");
    return 0;
}
