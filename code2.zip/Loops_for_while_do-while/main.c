#include <stdio.h>
#include <stdlib.h>

int main()
{
    //For Loop

    //for(initialization;condition;incre/decre)

    //5 * 1 = 5

//    int n,index;
//
//    printf("Enter any number to print the table:");
//    scanf("%d", &n);
//
//    for(index=1; index<=10; index++)
//    {
//        printf("%d * %d = %d\n", n, index, n*index);
//    }

    //While Loop

    //initializaton
    //while(condition)
    //incre/decre

//    int x;
//
//    x= 1;
//
//    while(x<=10){
//        printf("X is:%d\n",x);
//        x++;
//    }

    //do-while

    int x= 5,index=1;

    do{
       printf("5 * %d = %d\n", index, x * index);
       index++;
    }while(index<=10);

    return 0;
}
