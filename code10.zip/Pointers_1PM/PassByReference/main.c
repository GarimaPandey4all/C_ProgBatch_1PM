#include <stdio.h>
#include <stdlib.h>

void swap(int*, int*);

int main()
{
    int x = 20, y = 40;

    printf("Before Swap the value of a=%d and b=%d.\n",x, y);

    swap(&x, &y);

    printf("After Swap the value of a=%d and b=%d.",x, y);

    return 0;
}

void swap(int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}
