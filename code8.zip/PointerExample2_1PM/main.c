#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number=15, result;
    int *pnumber = &number;

    result = *pnumber + 100;

    printf("Value of result is:%d", result);

    return 0;
}
