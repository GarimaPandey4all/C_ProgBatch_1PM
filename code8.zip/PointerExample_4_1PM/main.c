#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number = 0;

    int *pnumber =  NULL;

    number = 20;

    pnumber = &number;

    *pnumber += 25; //*pnumber = *pnumber + 25;

    printf("Value is: %d", *pnumber);

    return 0;
}
