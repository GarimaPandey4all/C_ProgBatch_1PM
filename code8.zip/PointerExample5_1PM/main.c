#include <stdio.h>
#include <stdlib.h>

int main()
{
    int value=10;

    int *pvalue= &value;

    char ch='A';

    char *pch = &ch;

    printf("Size of Pvalue: %d\n", sizeof(*pvalue));

    printf("Size of Pch: %d", sizeof(*pch));

    return 0;
}
