#include <stdio.h>
#include <stdlib.h>

int main()
{
    long value = 999L;

    long *const pvalue = &value; //Constant Pointer

    *pvalue = 888L;  //OK

    long item = 1000L;

    pvalue = &item; //error: assignment read-only variable

    //value = 1026L;

    return 0;
}
