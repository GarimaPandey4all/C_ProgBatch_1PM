#include <stdio.h>
#include <stdlib.h>

int main()
{
   const int value= 10;

   const int *pvalue = &value;

   int *const pitem = &value;

   const int value1= 11;

    //value = 11; //constant normal variable

    //*pvalue = 11; //pointer variable //value constant

    pitem = &value1; //constant pointer //address constant

    return 0;
}
