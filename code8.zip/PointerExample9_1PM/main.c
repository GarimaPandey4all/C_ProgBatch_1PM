#include <stdio.h>
#include <stdlib.h>

int main()
{
    long value = 999L;

    const long *pvalue = &value; //value will be constant

    //*pvalue = 888L; //error : Assignment read-only location

    long item = 1000L;

    pvalue = &item; //re-initialize of address in pvalue

    return 0;
}
