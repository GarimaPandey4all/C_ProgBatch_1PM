#include <stdio.h>
#include <stdlib.h>

int main()
{
    int *pt;

    *pt = 5;

    printf("Value is:%d", *pt);

    return 0;
}
