#include <stdio.h>
#include <stdlib.h>

int main()
{
    int r, n, sum =0, temp;

    printf("Enter any number to check whether the number is palindrome or not?");
    scanf("%d", &n);

    temp = n;

    while(n>0)
    {
        r = n % 10; //5225 //remainder= 5225
        sum = sum * 10 + r; //0 * 10 + 5= 5225
        n = n /10; //quotient= 522, 52, 5, 0
    }

    n = temp;

    (n==sum) ? printf("Number is Palindrome") : printf("Not a Palindrome number");

    return 0;
}
