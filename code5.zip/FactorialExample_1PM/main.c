#include <stdio.h>
#include <stdlib.h>

int main()
{
    int fact=1, i, n;

    printf("Enter any Number:");
    scanf("%d", &n);

    for(i=1; i<=n; i++)
        fact *= i; // fact = fact * i; //Assignment Operator

    printf("Factorial of %d! is:%d", n, fact);

    return 0;
}
