#include <stdio.h>
#include <stdlib.h>

int main()
{
    int reverse=0, n, r;

    printf("Enter any number:");
    scanf("%d", &n);

    while(n>0)
    {
        r = n % 10; //234= 4,3,2
        reverse = reverse * 10 + r;
        n = n /10; //234= 23
    }

    printf("Reverse is:%d", reverse);

    return 0;
}
