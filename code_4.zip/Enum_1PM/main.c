#include <stdio.h>
#include <stdlib.h>

//enum enum_name {const1, const2,.......};


int main()
{
    enum Gender {Male , Female};

    enum Gender MyGender= Male;

    enum Gender AnotherMyGender = Female;

    printf("Male is:%d\n", MyGender);
    printf("Female is:%d", AnotherMyGender);

    return 0;
}
