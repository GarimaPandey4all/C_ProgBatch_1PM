#include <stdio.h>
#include <stdlib.h>

int main()
{

    enum Week {Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday};

    enum Week Today=Monday;

    switch(Today)
    {
    case 0:
        printf("Today is Monday");
        break;

    case 1:
        printf("Today is Tuesday");
        break;

    case 2:
        printf("Today is Wednesday");
        break;

    case 3:
        printf("Today is Thursday");
        break;

    case 4:
        printf("Today is Friday");
        break;

    case 5:
        printf("Today is Saturday");
        break;

    case 6:
        printf("Today is Sunday");
        break;

    default:
            printf("You have entered the wrong case");
    }


    return 0;
}
