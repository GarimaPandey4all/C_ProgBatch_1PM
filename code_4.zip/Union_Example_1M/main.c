#include <stdio.h>
#include <stdlib.h>

int main()
{
    union Data
    {
        int i;
        int b;
        int c;
    };

    union Data data;

    data.i = 60;
    printf("I is:%d\n", data.i);
    data.b = 30;
    printf("B is:%d\n", data.b);
    data.c = 20;
    printf("C is:%d", data.c);

    printf("Size of Data:%d",sizeof(data));

    return 0;
}
