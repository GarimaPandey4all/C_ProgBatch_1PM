#include <stdio.h>
#include <stdlib.h>

int main()
{
    enum Week {Monday, Tuesday, Wednesday=9, Thursday, Friday, Saturday, Sunday};

    enum Week Today= Sunday;

    printf("Today is:%d", Today);

    return 0;
}
