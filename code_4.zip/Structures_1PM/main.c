#include <stdio.h>
#include <stdlib.h>
 struct Date
    {
        int Month;
        int Day;
        int Year;
    }date,date2,date3;




int main()
{
    //struct Date date;
        date.Month = 10;
        date.Day =2;
        date.Year = 2020;

        date2.Month = 10;
        date2.Day =2;
        date2.Year = 2020;

        printf("Today is:%d/%d/%d\n", date.Month, date.Day, date.Year);

        printf("Today is:%d/%d/%d\n", date2.Month, date2.Day, date2.Year);

        printf("Size of Struct Variable:%d", sizeof(date));

    return 0;
}
