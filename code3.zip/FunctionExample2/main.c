#include <stdio.h>
#include <stdlib.h>

/* Function has 4 types

    1. Function without Arguments and without return value
    2. Function without Arguments and with return value
    3. Function with Arguments and without return value
    4. Function with Arguments and with return value

*/

//First Way

void Showdata();

int main()
{
    Showdata();

    return 0;
}

void Showdata()
{
    printf("Hello World");
}

