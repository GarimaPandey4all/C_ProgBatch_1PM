#include <stdio.h>
#include <stdlib.h>

void sum(); //function declaration

//function prototype
////Return_type function_name(arguments) //function header
//{
//    //funtion body
//}

int main()
{

    sum(); //function calling
    return 0;
}

//function defination

void sum()
{
int a, b, c;

    printf("Enter values for a & b");
    scanf("%d %d", &a, &b);

    c = a + b;

    printf("Sum is: %d", c);
}
