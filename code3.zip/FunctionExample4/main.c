#include <stdio.h>
#include <stdlib.h>

// Function with Arguments and without return value

int sum(int , int);

int main()
{
    int x, y;

    sum(x, y);

    return 0;
}

int sum(int a, int b)
{
    printf("Enter values for a and b:");
    scanf("%d %d", &a, &b);

    printf("Sum is:%d", a+b);
}
