#include <stdio.h>
#include <stdlib.h>

// Function without Arguments and with return value

int sum();

int main()
{
    int result;

    result = sum();
    printf("Sum is:%d", result);
    return 0;
}

int sum()
{
    int a, b;

    printf("Enter values for a and b:");
    scanf("%d %d", &a, &b);

    return a + b;
}
