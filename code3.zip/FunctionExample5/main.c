#include <stdio.h>
#include <stdlib.h>

// Function with Arguments and with return value

int isEven(int);
int sub(int, int);

int main()
{
    int a, c, d, result;
    isEven(a);
    result = sub(c,d);
    printf("Sub is: %d", result);

    return 0;
}

int isEven(int number)
{
    int remainder;

    printf("Enter any number:");
    scanf("%d", &number);

    remainder = number % 2;

    (remainder == 0) ? printf("Number is Even\n") : printf("Number is Odd\n");

    return 0;
}
 int sub(int a, int b)
 {
     printf("Enter values for a and b:");
     scanf("%d %d", &a, &b);

     return a-b;
 }
