#include<stdio.h>
#include<conio.h>

void main()
{
	clrscr();

	if(printf("Ifit is raining"))
		printf("Swimming");

	else
		printf("Nothing");

	getch();

}