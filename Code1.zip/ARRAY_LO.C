#include<stdio.h>
#include<conio.h>

void main()
{
	float marks[10];
	const int count = 10;
	float sum = 0.0;
	float percentage = 0.0;
	int i;

	clrscr();

	printf("Enter Ten Marks:\n");
	for(i=0; i<count; i++)
	scanf("%f", &marks[i]);


	for(i=0; i<count; i++)
	sum += marks[i];

	printf("\nSum is:%.2f", sum);

	percentage = (sum/1000) * 100;

	printf("\nPercentage is:%.2f", percentage);

	if(percentage >= 50 && percentage <= 60)
		printf("\nD Grade");

	else if(percentage >= 60 && percentage <= 70)
		printf("\nC Grade");

	else if(percentage >= 70 && percentage <= 80)
		printf("\nB Grade");

	else if(percentage >= 80 && percentage <= 100)
		printf("\nA Grade");

	else
		printf("\nOtherwise Fail...");

	getch();
}