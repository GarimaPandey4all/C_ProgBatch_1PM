#include<stdio.h>
#include<conio.h>

void main()
{
	int A,B;
	//int C;
	clrscr();

	printf("Enter the Value for A:");
	scanf("%d", &A);

	printf("\nEnter the Value for B:");
	scanf("%d", &B);

	//Binary AND Operator

	if(A & B)
	printf("\nA & B is:");

	//Binary OR Operator

	if(A | B)
	printf("\nA | B is:");

	//Binary Unary Operator

	if(~A)
	printf("\nA's Complement:");

	//C = A | B;

	//printf("The Value of C is: %d", C);

	//Logical and Bitwise Example

	if(A && B)
	printf("\nA && B is True");

	if(A & B)
	printf("\nA & B is True: %d %d", A, B);

	getch();
}