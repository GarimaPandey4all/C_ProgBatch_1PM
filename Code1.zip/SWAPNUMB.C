/*
	Swap two numbers with and without third variable.
*/
#include<stdio.h>
#include<conio.h>

void main()
{
	int a=5,b=7,temp;
	clrscr();

	//Using Third Variable

	//printf("Before Swapping the value of a=%d and b=%d",a,b);

	//temp = a;
	//a = b;
	//b = temp;

	//printf("\nAfter Swapping the value of a=%d and b=%d",a,b);

	//Without Using Third Variable: + and -

	//a = a+b; // 5+7=12
	//b = a-b; // 12-7= 5
	//a = a-b; // 12-5=7

	//printf("\nAfter Swapping the value of a=%d and b=%d",a,b);

	//Without Using Third Variable: * and /

	a = a*b; // 5*7=35
	b = a/b; // 35/7= 5
	a = a/b; // 35/5=7

	printf("\nAfter Swapping the value of a=%d and b=%d",a,b);

	getch();
}