#include<stdio.h>
#include<conio.h>

void main()
{
	int percent=80;
	//const float Total_Marks = 1000.00;

	clrscr();

	if(percent > 50 && percent < 60)
		printf("\nD Grade");

	else if(percent > 60 && percent < 70)
		printf("\nC Grade");

	else if(percent > 70 && percent <= 80)
		printf("\nB Grade");

	else if(percent > 80 && percent <= 100)
		printf("\nA Grade");

	else
		printf("\nFail....");

	getch();

}