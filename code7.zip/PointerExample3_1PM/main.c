#include <stdio.h>
#include <stdlib.h>

int main()
{
    int count = 10, x;

    int *pnumber = NULL;

    pnumber = &count;

    x= *pnumber;

    printf("Count is=%d and x is=%d", count, x);

    return 0;
}
