#include <stdio.h>
#include <stdlib.h>

/*
    strcmp(a, b):

    a, b= 1

    b, a= -1

    a == a= 0

    abc , abe= 1


*/

int main()
{

    char str1[10];
    char str2[10];

    printf("Enter Str1:");
    gets(str1);

    printf("Enter Str2:");
    gets(str2);

    if(strcmp(str1, str2)==0)
        printf("You entered the same strings.");

    else
        printf("Not the same Strings.");

    return 0;
}
