#include <stdio.h>
#include <stdlib.h>

int main()
{
    char name[10];

    printf("Enter your name:");
    //scanf("%s", &name);

    gets(name); //Take Input String

    puts(name); //display output string
    printf("Your name is:%s", name);

    return 0;
}
