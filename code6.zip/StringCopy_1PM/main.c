#include <stdio.h>
#include <stdlib.h>

int main()
{
    char str1[10];
    char str2[10];

    printf("Enter value in str1:");
    gets(str1);

    printf("Enter value in str1:");
    gets(str2);

    printf("String 1 copying in String 2:%s", strcpy(str2, str1));

    return 0;
}
