#include <stdio.h>
#include <stdlib.h>

int main()
{
    char Firstname[10];
    char Lastname[10];

    printf("Enter your FirstName:");
    gets(Firstname);

    printf("Enter your LastName:");
    gets(Lastname);

    printf("After concatenation(joining) of Strings:%s", strcat(Firstname, Lastname));

    return 0;
}
