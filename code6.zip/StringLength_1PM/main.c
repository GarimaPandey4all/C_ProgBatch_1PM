#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char name[20];

    printf("Enter your name:");
    gets(name);

    printf("Your Name's length is:%d", strlen(name));

    return 0;
}
