#include <stdio.h>
#include <stdlib.h>

int main()
{
    char str1[10];

    printf("Enter any String:");
    gets(str1);

    printf("String to Lowercase:%s\n", strlwr(str1));

    printf("String to Uppercase:%s", strupr(str1));

    return 0;
}
